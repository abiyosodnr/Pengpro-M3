package main

import "fmt"

func main(){
  var r, luas float64
  const pi float64 = 22.0/7.0

  fmt.Scan(&r)
  luas = 4*pi*r*r
  fmt.Println(luas)
}

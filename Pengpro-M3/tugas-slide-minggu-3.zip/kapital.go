package main

import "fmt"

func main(){
 var huruf string
 var status bool

 fmt.Scan(&huruf)
 status = huruf[0] <= 90 && huruf[0] >= 65  
 fmt.Println(status)
}


package main

import "fmt"

func main(){
  var number int
  var duplicatedDigits int
  var x1, x2 int
  var digit1, digit2 int
  
  fmt.Scan(&number)
  
  x1 = number / 10
  number = number % 10
  x2 = number / 1
  digit1 = x1 * 1100
  digit2 = x2 * 11
  duplicatedDigits = digit1 + digit2
  fmt.Println(duplicatedDigits)
}
